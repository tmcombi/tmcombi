initialize();
global mode;

dim=10;

BaseClassifiersTrainSize1=32;
BaseClassifiersTrainSize2=32;
CombinerTrainSizeMin=32;
step=64;
n_steps=10;
CombinerTrainSizeMax=CombinerTrainSizeMin+n_steps*step;
TestSize=CombinerTrainSizeMax;

rng(0);
B1 = gendatd([BaseClassifiersTrainSize1/2,BaseClassifiersTrainSize1/2],dim);
B2 = gendatd([BaseClassifiersTrainSize2/2,BaseClassifiersTrainSize2/2],dim);
C = gendatd([CombinerTrainSizeMax/2,CombinerTrainSizeMax/2],dim);
D = gendatd([TestSize/2,TestSize/2],dim);

Base1=B1*qdc*classc;
Base2=B2*knnc([])*classc;
Base3=B2*ldc*classc;

Base=[Base1 Base2 Base3];
CB=C*Base;DB=D*Base;

stat=[];
for CombinerTrainSize = CombinerTrainSizeMin:step:CombinerTrainSizeMax
    CBpart=CB([1:CombinerTrainSize/2 (CombinerTrainSizeMax/2+1):(CombinerTrainSizeMax/2+CombinerTrainSize/2)],:);
    Vtmc = CBpart(:,1:2:size(CBpart,2))*tmc;
    CBpartVtmc=CBpart(:,1:2:size(CBpart,2))*Vtmc;
    DBVtmc=DB(:,1:2:size(DB,2))*Vtmc;DBmeanc=DB*meanc;
    rocErrTrain=[CBpartVtmc*testauc];
    rocErrTest=[DBVtmc*testauc DBmeanc*testauc];
    classErr=[CBpartVtmc*testc DBVtmc*testc DBmeanc*testc];
    stat=[stat; CombinerTrainSize rocErrTrain rocErrTest classErr];
    %disp([rocErrTrain rocErrTest classErr]);
end

%disp(stat);

if ~strcmp(mode,'createFigs')
    subplot(1,2,1);
else
    figure(1);
end
plot(stat(:,1),stat(:,2),'r-o', stat(:,1),stat(:,3),'b-o', stat(:,1),stat(:,4),'k--o');
legend('tmc train', 'tmc val', 'mean val','Location','best');
xlabel('training size');
ylabel('error');
if ~strcmp(mode,'createFigs')
    title('ROC-error');
else
    print_figure('test2a',2.52,2.82);
end

if ~strcmp(mode,'createFigs')
    subplot(1,2,2);
else
    figure(2);
end
plot(stat(:,1),stat(:,5),'r-o', stat(:,1),stat(:,6),'b-o', stat(:,1),stat(:,7),'k--o');
legend('tmc train', 'tmc val', 'mean val','Location','southeast');
xlabel('training size');
ylabel('error');
if ~strcmp(mode,'createFigs')
    title('Classification error');
else
    print_figure('test2b',2.52,2.82);
end

drawnow;