function initialize()
clear;
addpath('C:\Program Files\MATLAB\prtools\prtools');
global mode;
mode='default';
%mode='createFigs';
end

