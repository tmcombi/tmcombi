% a little bit modified copy of plotm.m from PRTools5

function handle = myplottmc(w)
[BoundariesP,BoundariesN,nodeP,nodeN,weightsP,weightsN] = getdata(w);
[n_bp,n_nodes_bp]=size(BoundariesP);
P=sum(weightsP);
Xs=sort(nodeP(:,1));
if Xs(size(Xs))~=1
   Xs=[Xs; 1]; 
end
if Xs(1)~=0
   Xs=[0; Xs]; 
end
B=[];
XsBase=Xs;
%start_color=[1 1 1];
%end_color=[0 0 0.5];
start_color=[.8 1 0.5]; %light green
end_color=[1 0 0]; %red
hold on;
h=area([0;1],[1 1]);
h.FaceColor = start_color;
for i=1:n_bp
    Xs=XsBase;
%    figure(i);
    boundary=BoundariesP(i,:);
    indx=(1:n_nodes_bp).*boundary;
    indx(indx==0)=[];
    boundary=nodeP(indx,:);
    [bb, indx]=sort(boundary(:,1));
    old_boundary=boundary(indx,:);
    Xint=old_boundary(:,1);
    Yint=old_boundary(:,2);
    if Xint(1)~=0
       Xint=[0;Xint];
       Yint=[1;Yint];
    end
    if Xint(size(Xint))~=1
       Xint=[Xint;1];
       Yint=[Yint;Yint(size(Yint,1))];
    end
    Ys=interp1(Xint,Yint,Xs,'previous');
    boundary=[];
    for j=1:size(old_boundary,1)-1
        toAdd=[old_boundary(j+1,1) old_boundary(j,2)];
        boundary=[boundary;old_boundary(j,:);toAdd];
        Xs=[Xs;toAdd(1)];
        Ys=[Ys;toAdd(2)];
    end
    boundary=[boundary;old_boundary(size(old_boundary,1),:)];
    if boundary(size(boundary,1))~=1
       boundary=[boundary;1 boundary(size(boundary,1),2)]; 
    end
    if boundary(1,2)~=1
       Xs=[Xs;boundary(1,1)];
       Ys=[Ys;1];
       boundary=[boundary(1,1) 1;boundary]; 
    end

    %scatter(boundary(:,1),boundary(:,2));
    Xs=sort(Xs);
    Ys=sort(Ys,'descend');
%    B=[B Ys];

    h=area(Xs,Ys);
    h.FaceColor = (n_bp-i)/n_bp*start_color+i/n_bp*end_color;
    %plot(Xs,Ys,'o-',boundary(:,1),boundary(:,2),'o-r');
    plot(boundary(:,1),boundary(:,2),'black');
    axis([0 1 0 1]);
    handle=0;
end
box on;
hold off;
%figure(77);
%	area(Xs,B);
return