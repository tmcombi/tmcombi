function [W] = tmc(A)

name='tmc';

if (nargin == 0) || (isempty(A))
    W = prmapping('tmc');
    W = setname(W,name);
    return; 
end

% remove too small classes, escape in case no two classes are left
[a,m,k,c,lablist,L,W] = cleandset(A,1); 
if ~isempty(W), return; end

%[m,k,c] = getsize(A);
%disp([newline 'm ' num2str(m) ' k ' num2str(k) ' c ' num2str(c)]);
if c ~= 2
    error('Expecting features corresponding to two classes');
end

nlab = getnlab(A);
%disp(nlab);
data=A.data;
%disp(data);

node = zeros(0,k);
p = zeros(0,1);
n = zeros(0,1);

for i = 1:m
    [Lia, Locb] = ismember(data(i,:), node, 'rows');
    if ~Lia
        node = [node; data(i,:)];
        if nlab(i) == 1
            p = [p 1];
            n = [n 0];
        else
            p = [p 0];
            n = [n 1];
        end
    else
        if nlab(i) == 1
            p(Locb) = p(Locb) + 1;
        else
            n(Locb) = n(Locb) + 1;
       end
    end
end

n_nodes = size(node,1);

s=[1:n_nodes];t=[1:n_nodes];
for i = 1:n_nodes
    for j = 1:n_nodes
        if i==j continue; end
        if node(i,:) <= node(j,:)
            s = [s i];
            t = [t j];
        end
    end
end

G=digraph(s,t,ones(1,size(s,2)),'OmitSelfLoops');
GfullAdj = adjacency(G);
G=transreduction(G);
Gadj = adjacency(G);

Layers=ones(1,n_nodes);
LayersNew=ones(0,n_nodes);

while ~isequal(Layers,LayersNew)
    if size(LayersNew,1)~=0
        Layers=LayersNew;
    end
    LayersNew = ones(0,n_nodes);     
    LayersAux = ones(0,n_nodes);     

    for i=1:size(Layers,1)
        [low,up,cx]=tmc_kernel_fast(Gadj,p,n,Layers(i,:));
        %cross check with other (slower) implementations
        if false
            [low1,up1,cx1]=tmc_kernel_very_slow(Gadj,p,n,Layers(i,:));
            [low2,up2,cx2]=tmc_kernel_slow(Gadj,p,n,Layers(i,:));
            if cx~=cx1 || cx~=cx2
                error('slow and fast implementations of tmc kernel produce qualitatively different results');
            end
        end        
        if sum(low) == 0 || sum(up) == 0
            LayersAux = [LayersAux; Layers(i,:)];
        else
            LayersAux = [LayersAux; up; low];
        end
    end

    i=0;
    while i<size(LayersAux,1)
        i=i+1;
        up=LayersAux(i,:);
        if i==size(LayersAux,1)
            LayersNew = [LayersNew; up];
            break;
        end
        low=LayersAux(i+1,:);
        p1=p*up';
        n1=n*up';
        p2=p*low';
        n2=n*low';
        if p1*n2<p2*n1
            LayersNew = [LayersNew; up+low];
            i=i+1;
        else
            LayersNew = [LayersNew; up];
        end
    end
end
Layers = LayersNew;

LayersNew=ones(0,n_nodes);
while ~isequal(Layers,LayersNew)
    if size(LayersNew,1)~=0
        Layers=LayersNew;
    end
    LayersNew = ones(0,n_nodes);     
    
    i=0;
    while i<size(Layers,1)
        i=i+1;
        up=Layers(i,:);
        if i==size(Layers,1)
            LayersNew = [LayersNew; up];
            break;
        end
        low=Layers(i+1,:);
        p1=p*up';
        n1=n*up';
        p2=p*low';
        n2=n*low';
        if p1*n2==p2*n1
            LayersNew = [LayersNew; up+low];
            i=i+1;
        else
            LayersNew = [LayersNew; up];
        end
    end
end
Layers = LayersNew;
n_layers = size(Layers,1);

BoundariesP = triu(ones(n_layers))'*Layers*(eye(n_nodes)-Gadj);
BoundariesP = max(BoundariesP,0);

BoundariesN = triu(ones(n_layers))'*Layers(n_layers:-1:1,:)*(eye(n_nodes)-Gadj');
BoundariesN = max(BoundariesN,0);

activeP=1:n_nodes;
activeP(sum(BoundariesP,1)==0)=[];

activeN=1:n_nodes;
activeN(sum(BoundariesN,1)==0)=[];

nodeP=node(activeP,:);
nodeN=node(activeN,:);

weightsP=Layers*p';
weightsN=Layers*n';

BoundariesP = BoundariesP(:,activeP);
BoundariesN = BoundariesN(:,activeN);

W = prmapping('tmc_map','trained',{BoundariesP,BoundariesN,nodeP,nodeN,weightsP,weightsN},getlablist(A),k,c);
W = setname(W,name);
W = allclass(W,lablist,L);     % complete classifier with missing classes
W = setcost(W,A);

end

function [A,b,C,an,n_nodes,n_edges,row,col,Gactive] = primary(Gadj,p,n,l)
P=sum(p.*l);
N=sum(n.*l);
C=N*p-P*n;

%active nodes
an = (1:size(l,2)).*l;
an(l==0) = [];

C = C(an);

n_nodes = sum(l);

Gactive = Gadj(an,an);

[row,col] = find(Gactive);
n_edges = size(row,1);

%primary linear program
A = zeros(n_edges,n_nodes);
for i=1:n_edges
    A(i,row(i))=1;
    A(i,col(i))=-1;
end
b=zeros(n_edges,1);

end

function res=feasible(A,b,x)
    res = true;
    r = A*x-b;
    if size(find(r>=0.01),1) > 0 || ~isequal(find(x>=0),[1:size(x,1)]') || ~isequal(find(x<=1),[1:size(x,1)]')
        res=false;
    end
end


%Slowest kernel!
function [low,up,cx] = tmc_kernel_very_slow(Gadj,p,n,l)
[A,b,C,an,n_nodes,n_edges,row,col,Gactive] = primary(Gadj,p,n,l);

if isequal(C, zeros(1,n_nodes))
    up=l;
    low=zeros(1,size(l,2));
    cx=0;
    return;
end

[x,fval,exitflag,output]=intlinprog(-C,1:n_nodes,A,b,[],[],zeros(1,n_nodes),ones(1,n_nodes));
if exitflag~=1
    error('solution of linear program cannot be found');
end
x=round(x');
x_compl=ones(1,n_nodes)-x;

if ~feasible(A,b,x')
    error('Primary program constraints are not satisfied');
end
cx=C*x';

up=zeros(1,size(l,2));
low=zeros(1,size(l,2));

up(1,an) = x;
low(1,an) = x_compl;
end

%Slow kernel!
function [low,up,cx] = tmc_kernel_slow(Gadj,p,n,l)
[A,b,C,an,n_nodes,n_edges,row,col,Gactive] = primary(Gadj,p,n,l);

if isequal(C, zeros(1,n_nodes))
    up=l;
    low=zeros(1,size(l,2));
    cx=0;
    return;
end

[x,fval,exitflag,output]=linprog(-C,A,b,[],[],zeros(1,n_nodes),ones(1,n_nodes));
if exitflag~=1
    error('solution of linear program cannot be found');
end

if 0.01 < sum(x)
    x=x/max(x);
end
x(x< 0.99)=0;x(x~=0)=1;x=x';

x_compl=ones(1,n_nodes)-x;
if ~feasible(A,b,x')
    error('Primary program constraints are not satisfied');
end
cx=C*x';

up=zeros(1,size(l,2));
low=zeros(1,size(l,2));

up(1,an) = x;
low(1,an) = x_compl;
end

%Fastest Kernel a.t.m.
function [low,up,cx] = tmc_kernel_fast(Gadj,p,n,l)
[A_prim,b_prim,C,an,n_nodes,n_edges,row,col,Gactive] = primary(Gadj,p,n,l);

row_=[];col_=[];weights_=[];
for i = find(C>0)
    row_=[row_;n_nodes+1];col_=[col_;i];weights_=[weights_;C(i)];
end
for i = find(C<0)
    row_=[row_;i];col_=[col_;n_nodes+2];weights_=[weights_;-C(i)];
end

H=digraph([row' 1:n_nodes+2 row_'] ,[col' 1:n_nodes+2 col_'], [Inf*ones(1,n_edges+n_nodes+2) weights_'],'OmitSelfLoops');
%plot(H,'Layout','force','EdgeLabel',H.Edges.Weight);
[mf,HF] = maxflow(H,n_nodes+1,n_nodes+2);

if mf == sum(C(C>0))
    up=zeros(1,size(l,2));
    low=zeros(1,size(l,2));
    up(1,an) = ones(1,n_nodes);
    cx=sum(C);
    return;
end

%st = HF.Edges.EndNodes;
%Hplot = plot(H,'EdgeLabel',H.Edges.Weight);
%Hplot.EdgeLabel = {};
%highlight(Hplot,HF,'EdgeColor','r','LineWidth',2);
%labeledge(Hplot,st(:,1),st(:,2),HF.Edges.Weight);

HFadj_tr=adjacency(HF)';
HFadj_tr=HFadj_tr(1:n_nodes,1:n_nodes);
[row1,col1] = find(HFadj_tr);
M=digraph([row' row1' 1:n_nodes] ,[col' col1' 1:n_nodes], 'OmitSelfLoops');
M=transclosure(M);
Madj=adjacency(M);
x=zeros(n_nodes,1);
%here i go: helping flows!
beta=zeros(1,n_nodes);
for i=find(C>0)
    idx = findedge(HF,n_nodes+1,i);
    if idx>0
        beta(i)=C(i)-HF.Edges.Weight(idx);
    else
        beta(i)=C(i);
    end
    if beta(i) > 0
        x(i)=1;
        [aux,targets] = find(Madj(i,:)>0);
        x(targets)=1;
    end
end

%%Activate this checks if needed
%x_prim=intlinprog(-C,1:n_nodes,A_prim,b_prim,[],[],zeros(1,n_nodes),ones(1,n_nodes));
%res = A_prim*x-b_prim;
%if size(find(res>=0.01)) > 0
%    error('Wrong solution - primary conditions are not satisfied!');
%end
%if C*x_prim ~= C*x
%    error('Wrong maximum of the solution!');
%end

x=round(x');
x_compl=ones(1,n_nodes)-x;

if ~feasible(A_prim,b_prim,x')
    error('Primary program constraints are not satisfied');
end
cx=C*x';

up=zeros(1,size(l,2));
low=zeros(1,size(l,2));

up(1,an) = x;
low(1,an) = x_compl;
end

