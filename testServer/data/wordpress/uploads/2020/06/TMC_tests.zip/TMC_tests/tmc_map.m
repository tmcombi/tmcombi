function F = tmc_map(T,W)

T=prdataset(T);

F=T;

[BoundariesP,BoundariesN,nodeP,nodeN,weightsP,weightsN] = getdata(W);

data=T.data;
n_data=size(data,1);

[n_bp,n_nodes_bp]=size(BoundariesP);
[n_bn,n_nodes_bn]=size(BoundariesN);
P=sum(weightsP);
N=sum(weightsN);

data_new=[];
for i = 1:n_data
    pos=0;
    neg=0;
    
    j = 0;k = n_bp+1;
    while k-j>1
        m=round((k+j)/2);
        boundary=BoundariesP(m,:);
        indx=(1:n_nodes_bp).*boundary;
        indx(indx==0)=[];
        boundary=nodeP(indx,:);
        if coveredP(boundary,data(i,:))
            k=m;
        else
            j=m;
        end
    end
    if j~=n_bp;
        pos=weightsP(k);
        neg=weightsN(k);
    end
    if false
        found=false;
        for j=1:n_bp
            boundary=BoundariesP(j,:);
            indx=(1:n_nodes_bp).*boundary;
            indx(indx==0)=[];
            boundary=nodeP(indx,:);
            if coveredP(boundary,data(i,:))
                found=true;             
                if j~=k
                    error('something wrong')
                end
                break;
            end
        end
        if found==false && k~=n_bp+1
            error('something wrong');
        end
    end
    
    j = 0;k = n_bn+1;
    while k-j>1
        m=round((k+j)/2);
        boundary=BoundariesN(m,:);
        indx=(1:n_nodes_bn).*boundary;
        indx(indx==0)=[];
        boundary=nodeN(indx,:);
        if coveredN(boundary,data(i,:))
            k=m;
        else
            j=m;
        end
    end
    if j~=n_bp;
        pos=pos+weightsP(n_bn-k+1);
        neg=neg+weightsN(n_bn-k+1);
    end
    if false
        found=false;
        for j=1:n_bn
            boundary=BoundariesN(j,:);
            indx=(1:n_nodes_bn).*boundary;
            indx(indx==0)=[];
            boundary=nodeN(indx,:);
            if coveredN(boundary,data(i,:))
                found=true;             
                if j~=k
                    error('something wrong')
                end
                break;
            end
        end
        if found==false && k~=n_bn+1
            error('something wrong');
        end
    end

    if pos+neg ~= 0
        data_new=[data_new;pos/(pos+neg) neg/(pos+neg)];        
    else
        data_new=[data_new;P/(P+N) N/(P+N)];
    end
end

F.data=data_new;

%F.data=mean(T.data(:,1:2:size(nclass,1)),2);
%F.data=[F.data mean(T.data(:,2:2:size(nclass,1)),2)];

F = setdata(T,F,getlabels(W));

end

function res = coveredP(boundary,point)
    res=false;
    for i=1:size(boundary,1)
        if boundary(i,:)<= point
            res=true;
            break;
        end
    end
end

function res = coveredN(boundary,point)
    res=false;
    for i=1:size(boundary,1)
        if point <= boundary(i,:)
            res=true;
            break;
        end
    end
end
