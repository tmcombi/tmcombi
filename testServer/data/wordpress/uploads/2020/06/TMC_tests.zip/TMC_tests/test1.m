initialize();
global mode;
dim=10;

BaseClassifiersTrainSize1=64;
BaseClassifiersTrainSize2=64;
CombinerTrainSizeMin=32;
step=64;
n_steps=15;
CombinerTrainSizeMax=CombinerTrainSizeMin+n_steps*step;
TestSize=CombinerTrainSizeMax;

rng(1234);
B1 = gendatd([BaseClassifiersTrainSize1/2,BaseClassifiersTrainSize1/2],dim);
B2 = gendatd([BaseClassifiersTrainSize2/2,BaseClassifiersTrainSize2/2],dim);
C = gendatd([CombinerTrainSizeMax/2,CombinerTrainSizeMax/2],dim);
D = gendatd([TestSize/2,TestSize/2],dim);

Base1=B1*qdc*classc;
Base3=B2*ldc*classc;

Base=[Base1 Base3];
CB=C*Base;DB=D*Base;

stat=[];
for CombinerTrainSize = CombinerTrainSizeMin:step:CombinerTrainSizeMax
    CBpart=CB([1:CombinerTrainSize/2 (CombinerTrainSizeMax/2+1):(CombinerTrainSizeMax/2+CombinerTrainSize/2)],:);
    Vtmc = CBpart(:,1:2:size(CBpart,2))*tmc;
    CBpartVtmc=CBpart(:,1:2:size(CBpart,2))*Vtmc;
    DBVtmc=DB(:,1:2:size(DB,2))*Vtmc;DBmeanc=DB*meanc;
    rocErrTrain=[CBpartVtmc*testauc];
    rocErrTest=[DBVtmc*testauc DBmeanc*testauc];
    classErr=[CBpartVtmc*testc DBVtmc*testc DBmeanc*testc];
    stat=[stat; CombinerTrainSize rocErrTrain rocErrTest classErr];
    %disp([rocErrTrain rocErrTest classErr]);
end

%disp(stat);

if ~strcmp(mode,'createFigs')
    subplot(2,2,1);
    scatterd(CBpart(:,1:2:size(CBpart,2)));
    H=title('tmc training set');
    LEG = findobj(H,'type','text');
    set(LEG,'FontSize',11)
    H=xlabel('base classifier 1');
    LEG = findobj(H,'type','text');
    set(LEG,'FontSize',11)
    H=ylabel('base classifier 2');
    LEG = findobj(H,'type','text');
    set(LEG,'FontSize',11);
else
    figure(1);
    data=CBpart(:,1:2:size(CBpart,2));
    x=data.data(:,1);
    y=data.data(:,2);
    label=data.nlab;
    %scatter(x,y,6,(label-1)*[0 1 0]+(2-label)*[1 0 0]);
    scatter(x,y,6,(label-1)*[220 20 60]/256+(2-label)*[50 205 50]/256);
    xlabel('base classifier 1');
    ylabel('base classifier 2');
    box on;
    print_figure('test1a',2.5,2.5);
end

if ~strcmp(mode,'createFigs')
    subplot(2,2,3);
else
    figure(3);
end
plot(stat(:,1),stat(:,2),'r-o', stat(:,1),stat(:,3),'b-o', stat(:,1),stat(:,4),'k--o');
legend('tmc train', 'tmc val', 'mean val','Location','best');
xlabel('training size');
ylabel('error');
if ~strcmp(mode,'createFigs')
    title('ROC-error');
else
    print_figure('test1c',2.5,2.5);
end

if ~strcmp(mode,'createFigs')
    subplot(2,2,4);
else
    figure(4);
end
plot(stat(:,1),stat(:,5),'r-o', stat(:,1),stat(:,6),'b-o', stat(:,1),stat(:,7),'k--o');
legend('tmc train', 'tmc val', 'mean val','Location','best');
xlabel('training size');
ylabel('error');
if ~strcmp(mode,'createFigs')
    title('Classification error');
else
    print_figure('test1d',2.5,2.5);
end


if ~strcmp(mode,'createFigs')
    subplot(2,2,2);
else
    figure(2);
end
myplottmc(Vtmc);
xlabel('base classifier 1');
ylabel('base classifier 2');
box on;
if ~strcmp(mode,'createFigs')
    title('Geodesic lines');
else
    print_figure('test1b',2.5,2.5);
end


drawnow;