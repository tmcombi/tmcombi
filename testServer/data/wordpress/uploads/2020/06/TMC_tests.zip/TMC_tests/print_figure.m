function print_figure(filename,width,height)

%width = 2.6;     % Width in inches
%height = 3.0;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 8;      % Fontsize
lw = 1.5;      % LineWidth
msz = 8;       % MarkerSize

pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]);
set(gca, 'FontSize', fsz, 'LineWidth', alw);


%set(gca,'XTick',0:0.3);
%set(gca,'YTick',0:700);

set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width, height];
set(gcf,'PaperPosition', myfiguresize);

print(filename,'-depsc2','-r600');
print(filename,'-dpng','-r600');

end

